/**
 * @fileOverview KChart 1.2  barchart
 * @author huxiaoqi567@gmail.com
 * @changelog
 * 支持两级柱图 柱形图默认刻度最小值0
 * 新增barClick事件
 */
;
KISSY.add('gallery/kcharts/1.2/barchart/index', function(S, Template, BaseChart, Raphael, Color, HtmlPaper, Legend, Theme, undefined, Tip,D,E) {

	var $ = S.all,
		Evt = S.Event,
		win = window,
		clsPrefix = "ks-chart-",
		themeCls = clsPrefix + "default",
		canvasCls = themeCls + "-canvas",
		evtLayoutCls = clsPrefix + "evtlayout",
		evtLayoutAreasCls = evtLayoutCls + "-areas",
		evtLayoutBarsCls = evtLayoutCls + "-bars",
		COLOR_TPL = "{COLOR}",
		color;

	var BarChart = function(cfg) {
		var self = this;
		self._cfg = cfg;
		self.init();
	};

	S.extend(BarChart, BaseChart, {
		init: function() {

			var self = this;

			self.chartType = "barchart";

			BaseChart.prototype.init.call(self, self._cfg);

			if (!self._$ctnNode[0]) return;

			var _defaultConfig = {
				themeCls: themeCls,
				autoRender: true,
				colors: [],
				stackable: false,
				title: {
					content: "",
					css: {
						"text-align": "center",
						"font-size": "16px"
					},
					isShow: true
				},
				subTitle: {
					content: "",
					css: {
						"text-align": "center",
						"font-size": "12px"
					},
					isShow: true
				},
				xLabels: {
					isShow: true,
					css: {
						"color": "#666",
						"font-size": "12px",
						"white-space": "nowrap",
						"position": "absolute" //修复ie7被遮住的Bug
					}
				},
				yLabels: {
					isShow: true,
					css: {
						"color": "#666",
						"font-size": "12px",
						"white-space": "nowrap",
						"position": "absolute" //修复ie7被遮住的Bug
					}
				},
				//横轴
				xAxis: {
					isShow: true,
					css: {
						color: "#eee",
						zIndex: 10
					},
					min: 0
				},
				//纵轴
				yAxis: {
					isShow: true,
					css: {
						zIndex: 10
					},
					num: 5,
					min: 0
				},
				//x轴上纵向网格
				xGrids: {
					isShow: true,
					css: {

					}
				},
				//y轴上横向网格
				yGrids: {
					isShow: true,
					css: {}
				},
				areas: {
					isShow: true,
					css: {

					}
				},
				bars: {
					isShow: true,
					css: {
						background: COLOR_TPL,
						"border": "1px solid #fff"
					},
					barsRatio: 0.6,
					barRatio: 0.5
				},
				// zoomType:"x"
				legend: {
					isShow: false
				},
				tip: {
					isShow: true,
					template: "",
					css: {

					},
					anim: {
						easing: "easeOut",
						duration: 0.3
					},
					offset: {
						x: 0,
						y: 0
					},
					boundryDetect: true,
					alignX: "right", //left center right
					alignY: "bottom"
				}
			};
			//柱形对象数组
			self._bars = {};

			//统计渲染完成的数组
			self._finished = [];

			//主题
			themeCls = self._cfg.themeCls || _defaultConfig.themeCls;

			self._cfg = S.mix(S.mix(_defaultConfig, Theme[themeCls], undefined, undefined, true), self._cfg, undefined, undefined, true);

			self.color = color = new Color({
				themeCls: themeCls
			});

			if (self._cfg.colors.length > 0) {

				color.removeAllColors();

			}

			for (var i in self._cfg.colors) {

				color.setColor(self._cfg.colors[i]);

			}
			self._cfg.autoRender && self.render(true);
		},
		//主标题
		drawTitle: function() {
			if(!this._cfg.title.isShow) return;
			var self = this,
				paper = self.htmlPaper,
				cls = themeCls + "-title",
				_cfg = self._cfg,
				ctn = self._innerContainer,
				//高度占 60%
				h = ctn.y * 0.6;

				self._title = paper.rect(0, 0, self._$ctnNode.width(), h).addClass(cls).css(S.mix({
					"line-height": h + "px"
				}, _cfg.title.css)).html(_cfg.title.content);
		},
		//副标题
		drawSubTitle: function() {
			if(!this._cfg.subTitle.isShow) return;
			var self = this,
				paper = self.htmlPaper,
				cls = themeCls + "-subtitle",
				_cfg = self._cfg,
				ctn = self._innerContainer,
				//高度占 40%
				h = ctn.y * 0.4;

				self._subTitle = paper.rect(0, ctn.y * 0.6, self._$ctnNode.width(), h).addClass(cls).css(S.mix({
					"line-height": h + "px"
				}, _cfg.subTitle.css)).html(_cfg.subTitle.content);
		},
		//画柱
		drawBar: function(groupIndex, barIndex, callback) {
			var self = this,
				_cfg = self._cfg,
				paper = self.paper,
				cls = canvasCls + "-bars",
				ctn = self._innerContainer,
				colorall = self.color.getColor(groupIndex),
				color = colorall['DEFAULT'],
				// 颜色配置钩子
				customcolor = (_cfg.colorhook && _cfg.colorhook(groupIndex,barIndex,colorall)),
				colornew = (customcolor && customcolor["DEFAULT"]) || color,
				_css = self.processAttr(_cfg.bars.css, colornew),
				isY = _cfg.zoomType == "x" ? false : true,
				barPos = self._barsPos[groupIndex][barIndex],
				x = (barPos.x - 0).toFixed(2),
				y = (barPos.y - 0).toFixed(2),
				w = (barPos.width - 0).toFixed(2),
				h = (barPos.height - 0).toFixed(2),
				rect;
			//允许动画
			if (_cfg.anim) {
				var duration = _cfg.anim.duration ? (S.isNumber(_cfg.anim.duration) ? _cfg.anim.duration : 0.5) : 0.5,
					easing = _cfg.anim.easing ? _cfg.anim.easing : "easeOut";
				if (isY) {
					var zeroX = BaseChart.prototype.data2GrapicData.call(self, 0, true, false);
					rect = paper.rect(zeroX, y, 0, h).attr({
						"posx": x,
						"posy": y
					}).addClass(cls).css(_css).animate({
						"width": w,
						"marginLeft": x - ctn.x
					}, duration, easing, function() {
						callback && callback();
					});
				} else {
					var zeroY = BaseChart.prototype.data2GrapicData.call(self, 0, false, true);
					rect = paper.rect(x, zeroY, w, 0).attr({
						"posx": x,
						"posy": y
					}).addClass(cls).css(_css).animate({
						"height": h,
						"marginTop": y - ctn.y
					}, duration, easing, function() {
						callback && callback();
					});
				}
			} else {
				rect = paper.rect(x, y, w, h).attr({
					"posx": x,
					"posy": y
				}).addClass(cls).css(_css);
				callback && callback();
			}
			return rect;
		},
		/*
			TODO 计算柱形位置信息
			bar的数量和间隔数量是 n 和 n-1的关系
			len * barwidth + (len - 1) * barwidth / barRatio  = offsetWidth => barWidth = offsetWidth/(len + (len - 1) / barRatio)
		*/
		getBarsPos: function() {
			var self = this,
				zoomType = self._cfg.zoomType,
				stackable = self._cfg.stackable,
				ctn = self._innerContainer,
				isY = zoomType == "y",
				len = stackable ? 1 : BaseChart.prototype.obj2Array(self._clonePoints).length, //若是堆叠图 则为1
				barsRatio = self._cfg.bars.barsRatio, //一组柱的占空比
				barRatio = self._cfg.bars.barRatio, //单根柱子的占空比
				areaWidth = isY ? (self._pointsY.length > 1 ? (self._pointsY[1].y - self._pointsY[0].y) : ctn.height) : (self._pointsX.length > 1 ? (self._pointsX[1].x - self._pointsX[0].x) : ctn.width), //area总宽度
				offsetWidth = areaWidth * barsRatio, //柱子部分的宽度
				rate = barRatio >= 1 ? 0 : (1 - barRatio) / barRatio,
				barWidth = offsetWidth / (len + (len - 1) * rate), //柱子宽度
				spaceWidth = barWidth * (1 - barRatio) / barRatio, //柱子间隔宽度
				barAndSpaceWidth = stackable ? 0 : barWidth + spaceWidth,
				ctnY = self._innerContainer.bl.y,
				ctnX = self._innerContainer.bl.x,
				offset = (areaWidth * (1 - barsRatio) - areaWidth) / 2,
				stackArray = []; //用来标记当前堆叠的坐标

			self._barsPos = {};

			for (var i in self._points) {
				var tmpArray = [];
				//水平柱形图
				if (isY) {
					var zeroX = BaseChart.prototype.data2GrapicData.call(self, 0, true, false);
					for (var j in self._points[i]) {
						var barPosInfo = {},
							x = self._points[i][j].x,
							w = Math.abs(x - zeroX);

						barPosInfo.y = offset + self._points[i][j].y;
						//是否是堆叠图
						if (stackable) {
							barPosInfo.x = ctnX + (stackArray[j] || 0);
							stackArray[j] = stackArray[j] ? stackArray[j] + w : w;
						} else {
							barPosInfo.x = x > zeroX ? x - w : zeroX - w;
						}
						barPosInfo.width = w;
						barPosInfo.height = barWidth;
						tmpArray.push(barPosInfo);
					}
				} else {
					var zeroY = BaseChart.prototype.data2GrapicData.call(self, 0, false, true);
					for (var j in self._points[i]) {
						var barPosInfo = {},
							y = self._points[i][j].y,
							h = Math.abs(zeroY - y);

						barPosInfo.x = offset + self._points[i][j].x;
						//是否是堆叠图
						if (stackable) {
							barPosInfo.y = y - (stackArray[j] || 0);
							stackArray[j] = stackArray[j] ? stackArray[j] + h : h;
						} else {
							barPosInfo.y = y > zeroY ? zeroY : y;
						}
						barPosInfo.width = barWidth;
						barPosInfo.height = h;
						tmpArray.push(barPosInfo);
					}
				}
				offset += barAndSpaceWidth;
				self._barsPos[i] = tmpArray;
			}
		},
		/*
			画所有柱
		*/
		drawBars: function(callback) {
			var self = this,
				_cfg = self._cfg;

			for (var i in self._barsPos) {
				var bars = [],
					posInfos = [];
				// 只计算一次getColor
				var colorObject = color.getColor(i);
				for (var j in self._barsPos[i]) {
					var tmpcolor;
					var realColorObj;
					// 如果有colorhook自定义颜色
					if(_cfg.colorhook){
						tmpcolor = _cfg.colorhook(i,j,colorObject);
						if(tmpcolor)
							realColorObj = tmpcolor;
						else
							realColorObj = colorObject;
					}else{
						realColorObj = colorObject;
					}
					var barPos = self._barsPos[i][j];
					posInfos[j] = barPos;
					bars[j] = self.drawBar(i, j, function() {
						self._finished.push(true);
						if (callback && self._finished.length == self._cfg.series.length) {
							callback();
						}
					}).attr({
						"barGroup": i,
						"barIndex": j,
						"defaultColor": realColorObj.DEFAULT,
						"hoverColor": realColorObj.HOVER
					});
				}
				var barObj = {
					bars: bars,
					posInfos: posInfos,
					color: colorObject
				};
				self._bars[i] = barObj;
			}
			return self._bars;
		},
		//x轴上 平行于y轴的网格线
		drawGridsX: function() {
			if (!this._cfg.xGrids.isShow) return;
			var self = this,
				points = self._points[0],
				gridPointsX;

			self._gridsX = [];

			if (self._cfg.zoomType == "x") {
				gridPointsX = function() {
					var len = points.length,
						tmp = [];
					if (len > 1) {
						var d = (points[1]['x'] - points[0]['x']) / 2;
						tmp.push({
							x: points[0]['x'] - d
						})
						for (var i in points) {
							tmp.push({
								x: points[i]['x'] - (-d)
							});
						}
					}
					return tmp;
				}();

				for (var i = 0, len = gridPointsX.length; i < len; i++) {
					self._gridsX.push(self.drawGridX(gridPointsX[i]));
				}
			} else {
				for (var i in self._pointsX) {
					self._gridsX.push(self.drawGridX(self._pointsX[i]));
				}
			}
			return self._gridsX;
		},
		drawGridX: function(point, css) {
			var self = this,
				y = self._innerContainer.tl.y,
				h = self._innerContainer.height,
				css = css || self._cfg.xAxis.css,
				paper = self.htmlPaper,
				cls = self._cfg.themeCls + "-gridsx";

			return paper.lineY(point.x, y, h).addClass(cls).css(self._cfg.xGrids.css);
		},
		//y轴上 平行于x轴的网格线
		drawGridY: function(point, css) {
			var self = this,
				w = self._innerContainer.width,
				css = css || self._cfg.yGrids.css,
				paper = self.htmlPaper,
				cls = self._cfg.themeCls + "-gridsy";

			return paper.lineX(point.x, point.y, w).addClass(cls).css(css);

		},
		//y轴上 平行于x轴的网格线
		drawGridsY: function() {
			if (!this._cfg.yGrids.isShow) return;
			var self = this,
				x = self._innerContainer.tl.x,
				isY = self._cfg.zoomType == "x" ? false : true;

			self._gridsY = [];

			for (var i = 0, len = self._pointsY.length; i < len; i++) {
				self._gridsY[i] = {
					0: self.drawGridY({
						x: x,
						y: self._pointsY[i].y
					}),
					num: isY ? self.coordNumX[i] : self.coordNum[i]
				};
			}
		},
		//x轴
			drawAxisX: function() {
			if(!this._cfg.xAxis.isShow) return;
			var self = this,
				_innerContainer = self._innerContainer,
				bl = _innerContainer.bl,
				w = _innerContainer.width,
				paper = self.htmlPaper,
				cls = self._cfg.themeCls + "-axisx";

			self._axisX = paper.lineX(bl.x, bl.y, w).addClass(cls).css(self._cfg.xAxis.css || {});
			return self._axisX;
		},
		//y轴
		drawAxisY: function() {
			if(!this._cfg.yAxis.isShow) return;
			var self = this,
				_innerContainer = self._innerContainer,
				tl = _innerContainer.tl,
				h = _innerContainer.height,
				paper = self.htmlPaper,
				cls = self._cfg.themeCls + "-axisy";

			self._axisY = paper.lineY(tl.x, tl.y, h).addClass(cls).css(self._cfg.yAxis.css || {});

			return self._axisY;
		},
		drawLabelsX: function() {
			if(!this._cfg.xLabels.isShow) return;
			var self = this,
				_cfg = self._cfg,
				isY = _cfg.zoomType == "y" ? true : false;

			if (isY) {
				for (var i in self._pointsX) {
					self._labelX[i] = {
						0: self.drawLabelX(i, self._pointsX[i]['number'])
					};
				}
			} else {
				//画x轴刻度线
				for (var i in self._cfg.xAxis.text) {
					self._labelX[i] = {
						0: self.drawLabelX(i, self._cfg.xAxis.text[i])
					};
				}
			}
		},
		drawLabelsY: function() {
			if(!this._cfg.yLabels.isShow) return;
			var self = this,
				_cfg = self._cfg,
				isY = _cfg.zoomType == "x" ? false : true;

			if (isY) {
				//画x轴刻度线
				for (var i in self._cfg.yAxis.text) {
					self._labelY[i] = {
						0: self.drawLabelY(i, self._cfg.yAxis.text[i])
					}
				}
			} else {
				//画y轴刻度线
				for (var i in self._pointsY) {
					self._labelY[i] = {
						0: self.drawLabelY(i, self._pointsY[i].number),
						'num': self._pointsY[i].number
					}
				}
			}
		},
		//横轴标注
		drawLabelX: function(index, text) {
			var self = this,
				paper = self.htmlPaper,
				labels = self._pointsX,
				len = labels.length || 0,
				label,
				cls = self._cfg.themeCls + "-xlabels",
				tpl = "{{data}}",
				content = "";
			if (index < len) {
				tpl = self._cfg.xLabels.template || tpl;
				if (S.isFunction(tpl)) {
					content = tpl(index, text);
				} else {
					content = Template(tpl).render({
						data: text
					});
				}
				label = labels[index];
				label[0] = paper.text(label.x, label.y, '<span class=' + cls + '>' + content + '</span>', "center").children().css(self._cfg.xLabels.css);
				return label[0];
			}
		},
		//纵轴标注
		drawLabelY: function(index, text) {
			var self = this,
				paper = self.htmlPaper,
				cls = self._cfg.themeCls + "-ylabels",
				tpl = "{{data}}",
				content = "";

			tpl = self._cfg.yLabels.template || tpl;
			if (S.isFunction(tpl)) {
				content = tpl(index, text);
			} else {
				content = Template(tpl).render({
					data: text
				});
			}

			return content && paper.text(self._pointsY[index].x, self._pointsY[index].y, '<span class=' + cls + '>' + content + '</span>', "right", "middle").children().css(self._cfg.yLabels.css);
		},
		//渲染tip
		renderTip: function() {
			if(!this._cfg.tip.isShow) return;
			var self = this,
				_cfg = self._cfg,
				ctn = self._innerContainer,
				boundryCfg = _cfg.tip.boundryDetect ? {
					x: ctn.tl.x,
					y: ctn.tl.y,
					width: ctn.width,
					height: ctn.height
				} : {},
				tipCfg = S.mix(_cfg.tip, {
					rootNode: self._$ctnNode,
					clsName: _cfg.themeCls,
					boundry: boundryCfg
				});

			self.tip = new Tip(tipCfg);
			return self.tip;
		},
		//渲染事件层
		renderEvtLayout: function() {
			var self = this,
				ctn = self._innerContainer,
				y = ctn.tl.y,
				points = self._points[0],
				h = ctn.height,
				multiple = self._multiple,
				evtBars = self._evtEls._bars = [],
				paper,
				x;

			if (!self._evtEls.paper) {
				paper = self._evtEls.paper = new HtmlPaper(self._$ctnNode, {
					clsName: evtLayoutCls,
					prependTo: false, //appendTo
					width: ctn.width,
					height: h,
					left: ctn.tl.x,
					top: ctn.tl.y,
					css: {
						"z-index": 20,
						background: "#fff",
						filter: "alpha(opacity =1)",
						"-moz-opacity": 0.01,
						"-khtml-opacity": 0.01,
						opacity: 0.01
					}
				});
			} else {
				paper = self._evtEls.paper;
			}

			for (var i in self._barsPos) {
				var bars = [];
				for (var j in self._barsPos[i]) {
					var barPos = self._barsPos[i][j];
					bars[j] = paper.rect(barPos.x, barPos.y, barPos.width, barPos.height).addClass(evtLayoutBarsCls).attr({
						"barGroup": i,
						"barIndex": j
					});
				}
				self._evtEls._bars.push(bars);
			}
			return paper;
		},
		clearEvtLayout: function() {
			var self = this;

			if (self._evtEls._bars) {
				for (var i in self._evtEls._bars) {
					for (var j in self._evtEls._bars[i]) {
						self._evtEls._bars[i][j].remove();
					}
				}
			}
		},
		renderLegend: function() {
			if(!this._cfg.legend.isShow) return;
			var self = this,
				legendCfg = self._cfg.legend,
				container = (legendCfg.container && $(legendCfg.container)[0]) ? $(legendCfg.container) : self._$ctnNode;

			var innerContainer = self._innerContainer;
			var colors = self.color._colors, //legend icon 的颜色表，循环
				len = colors.length,
				cfg = self._cfg,
				series = self._cfg.series
			var __legendCfg = S.map(series, function(serie, i) {
				i = i % len;
				var item = {},
					color = colors[i]
					item.text = serie.text;
				item.DEFAULT = color.DEFAULT;
				item.HOVER = color.HOVER;
				return item;
			});
			var globalConfig = S.merge({
				// icontype:"circle",
				// iconsize:10,
				interval: 20, //legend之间的间隔
				iconright: 5, //icon后面的空白
				showicon: true //默认为true. 是否显示legend前面的小icon——可能用户有自定义的需求
			}, cfg.legend.globalConfig);

			self.legend = new Legend({
				container: container,
				bbox: {
					width: innerContainer.width,
					height: innerContainer.height,
					left: innerContainer.x,
					top: innerContainer.y
				},
				align: cfg.legend.align || "bc",
				offset: cfg.legend.offset || (/t/g.test(cfg.legend.align) ? [0, 0] : [0, 20]),
				globalConfig: globalConfig,
				config: __legendCfg
			});

			self.legend.on("click", function(evt) {
				var i = evt.index,
					$text = evt.text,
					$icon = evt.icon,
					el = evt.el
				if (el.hide != 1) {
					this.hideBar(i);
					el.hide = 1;
					el.disable();
				} else {
					this.showBar(i);
					el.hide = 0;
					el.enable();
				}
			}, this);
			return self.legend;
		},
		render: function(clear) {

			var self = this,

				_cfg = self._cfg,

				ctn = self._innerContainer,

				themeCls = _cfg.themeCls;

			clear && self._$ctnNode.html("");

			self.raphaelPaper = Raphael(self._$ctnNode[0], _cfg.width, _cfg.height);
			//渲染html画布 只放图形
			self.paper = new HtmlPaper(self._$ctnNode, {
				clsName: canvasCls,
				width: ctn.width,
				height: ctn.height,
				left: ctn.tl.x,
				top: ctn.tl.y
			});
			//clone
			self._clonePoints = self._points;

			self.getBarsPos();
			//渲染html画布
			self.htmlPaper = new HtmlPaper(self._$ctnNode, {
				clsName: themeCls
			});

			self.drawTitle();

			self.drawSubTitle();
			//事件层
			self.renderEvtLayout();
			//渲染tip
			self.renderTip();
			//画x轴上的平行线
			self.drawGridsX();

			self.drawGridsY();
			//画横轴
			self.drawAxisX();

			self.drawAxisY();
			//画横轴刻度
			self.drawLabelsX();

			self.drawLabelsY();

			self.renderLegend();
			//画柱
			self.drawBars(function() {

				self.afterRender();

				self.fix2Resize();
			});

			self.bindEvt();

			S.log(self);

		},

		bindEvt: function() {
			var self = this,
				_cfg = self._cfg;
			// 先解绑事件
			self.unbindEvt();

			Evt.on($("." + evtLayoutBarsCls, self._$ctnNode), "mouseenter", function(e) {
				var $evtBar = $(e.currentTarget),
					barIndex = $evtBar.attr("barIndex"),
					barGroup = $evtBar.attr("barGroup");
				_cfg.tip.isShow && self.tipHandler(barGroup, barIndex);

				self.barChange(barGroup, barIndex);

			});

			Evt.on($("." + evtLayoutBarsCls, self._$ctnNode), "click", function(e) {
				var $evtBar = $(e.currentTarget),
					barIndex = $evtBar.attr("barIndex"),
					barGroup = $evtBar.attr("barGroup");

				self.barClick(barGroup, barIndex);

			});

			Evt.on($("." + evtLayoutBarsCls, self._$ctnNode), "mouseleave", function(e) {

				var $evtBar = $(e.currentTarget),
					barIndex = $evtBar.attr("barIndex"),
					barGroup = $evtBar.attr("barGroup"),
					$bar = self._bars[barGroup]['bars'][barIndex];
				$bar.css({
					"background": $bar.attr("defaultColor")
				});
			});

			Evt.on(self._evtEls.paper.$paper, "mouseleave", function(e) {
				self.tip && self.tip.hide();
				self.paperLeave();
			})

		},
		unbindEvt: function() {
			var self = this;
			Evt.detach($("." + evtLayoutBarsCls, self._$ctnNode), "mouseenter");
			Evt.detach($("." + evtLayoutBarsCls, self._$ctnNode), "click");
			Evt.detach($("." + evtLayoutBarsCls, self._$ctnNode), "mouseleave");
			self._evtEls.paper && Evt.detach(self._evtEls.paper.$paper, "mouseleave");
		},
		paperLeave: function() {
			var self = this;
			self.fire("paperLeave", self);
		},
		barChange: function(barGroup, barIndex) {
			var self = this,
				currentBars = self._bars[barGroup],
				e = S.mix({
					target: currentBars['bars'][barIndex],
					currentTarget: currentBars['bars'][barIndex],
					barGroup: Math.round(barGroup),
					barIndex: Math.round(barIndex)
				}, self._points[barGroup][barIndex]);

			self.fire("barChange", e);
		},
		barClick: function(barGroup, barIndex) {
			var self = this,
				currentBars = self._bars[barGroup],
				e = S.mix({
					target: currentBars['bars'][barIndex],
					currentTarget: currentBars['bars'][barIndex],
					barGroup: Math.round(barGroup),
					barIndex: Math.round(barIndex)
				}, self._points[barGroup][barIndex]);
			self.fire("barClick", e);
		},
		tipHandler: function(barGroup, barIndex) {
			var self = this,
				_cfg = self._cfg,
				tip = self.tip,
				isY = _cfg.zoomType == "y" ? true : false,
				$tip = tip.getInstance(),
				$bar = self._bars[barGroup]['bars'][barIndex],
				defaultColor = $bar.attr("defaultColor"),
				tpl = self._cfg.tip.template,
				posx = isY ? $bar.attr("posx") - (-$bar.width()) - (-self._innerContainer.x) : $bar.attr("posx"),
				posy = $bar.attr("posy"),
				tipData = S.merge(self._points[barGroup][barIndex].dataInfo, _cfg.series[barGroup]);
			//删除data 避免不必要的数据
			delete tipData.data;
			self._points[barGroup][barIndex]["dataInfo"],

			$bar.css({
				"background": $bar.attr("hoverColor")
			});

			if (!tpl) return;
			S.mix(tipData, {
				groupindex: barGroup,
				barindex: barIndex
			});
			tip.fire("setcontent", {
				data: tipData
			})
			tip.fire("move", {
				x: posx,
				y: posy,
				style: self.processAttr(_cfg.tip.css, defaultColor)
			});
		},
		//处理网格和标注
		animateGridsAndLabels: function() {
			var self = this,
				cfg = self._cfg,
				zoomType = cfg.zoomType;
			if (zoomType == "y") {
				for (var i in self._labelX) {
					self._labelX[i] && self._labelX[i][0] && $(self._labelX[i][0]).remove();
				}
				for(var i in self._gridsX){
					self._gridsX[i] && self._gridsX[i][0] && $(self._gridsX[i][0]).remove();
				}
				self.drawLabelsX();
				self.drawGridsX();
			} else if (zoomType == "x") {
				for (var i in self._labelY) {
					self._labelY[i] && self._labelY[i][0] && self._labelY[i][0].remove();
				}
				for(var i in self._gridsY){
					self._gridsY[i] && self._gridsY[i][0] && self._gridsY[i][0].remove();
				}
				self.drawGridsY();
				self.drawLabelsY();
			}
		},
		processAttr: function(attrs, color) {

			var newAttrs = S.clone(attrs);

			for (var i in newAttrs) {
				if (newAttrs[i] && typeof newAttrs[i] == "string") {
					newAttrs[i] = newAttrs[i].replace(COLOR_TPL, color);
				}
			}

			return newAttrs;
		},
		showBar: function(barIndex) {

			var self = this,
				ctn = self._innerContainer;

			BaseChart.prototype.recoveryData.call(self, barIndex);

			self._clonePoints[barIndex] = self._points[barIndex];

			self.animateGridsAndLabels();

			self.getBarsPos();
			//柱子动画
			for (var i in self._bars)
				if (i != barIndex) {

					for (var j in self._bars[i]['bars']) {

						if (self._barsPos[i]) {

							var barPos = self._barsPos[i][j];

							barPos && self._bars[i]['bars'][j].stop().animate({
								"height": barPos.height,
								"width": barPos.width,
								"marginTop": barPos.y - ctn.y,
								marginLeft: barPos.x - ctn.x
							}, 0.4, "easeOut", function() {});

							self._bars[i]['bars'][j].attr({
								"posx": barPos.x,
								"posy": barPos.y
							});
						}

					}

				}

			var posInfos = [],
				bars = [];
			var colorObject = color.getColor(barIndex);
			for (var j in self._barsPos[barIndex]) {
				var tmpcolor;
				var realColorObj;
				if(self._cfg.colorhook){
					tmpcolor = self._cfg.colorhook(barIndex,j,colorObject);
					if(tmpcolor)
						realColorObj = tmpcolor;
					else
						realColorObj = colorObject;
				}else{
					realColorObj = colorObject;
				}
				var barPos = self._barsPos[barIndex][j];

				posInfos[j] = barPos;
				bars[j] = self.drawBar(barIndex, j).attr({
					"barGroup": barIndex,
					"barIndex": j,
					"defaultColor": realColorObj.DEFAULT,
					"hoverColor": realColorObj.HOVER
				});

			}

			self._bars[barIndex] = {
				bars: bars,
				posInfos: posInfos,
				color: colorObject
			};

			self.clearEvtLayout();

			self.renderEvtLayout();

			self.bindEvt();

			S.log(self);
		},
		fix2Resize: function() {
			var self = this,
				$ctnNode = self._$ctnNode;
			self._cfg.anim = "";
			var rerender = S.buffer(function() {
				self.init();
			}, 200);
			!self.__isFix2Resize && self.on("resize", function() {
				self.__isFix2Resize = 1;
				rerender();
			})
		},
		hideBar: function(barIndex) {
			var self = this,
				ctn = self._innerContainer;

			BaseChart.prototype.removeData.call(self, barIndex);
			delete self._clonePoints[barIndex];
			self.animateGridsAndLabels();
			self.getBarsPos();
			for (var i in self._bars[barIndex]['bars']) {
				self._bars[barIndex]['bars'][i].remove();
			}
			//柱子动画
			for (var i in self._bars)
				if (i != barIndex) {
					for (var j in self._bars[i]['bars']) {
						var barPos = self._barsPos[i] ? self._barsPos[i][j] : "";
						barPos && self._bars[i]['bars'][j].stop().animate({
							"height": barPos.height,
							"width": barPos.width,
							"marginTop": barPos.y - ctn.y,
							marginLeft: barPos.x - ctn.x
						}, 0.4, "easeOut", function() {

						});
						self._bars[i]['bars'][j].attr({
							"posx": barPos.x,
							"posy": barPos.y
						});
					}
				}

			self.clearEvtLayout();

			self.renderEvtLayout();

			self.bindEvt();

			S.log(self);
		},
		afterRender: function() {
			var self = this;
			self.fire("afterRender", self);
		},
		/*
			TODO get htmlpaper
			@deprecated As Of KCharts 1.2 replaced by
			getHtmlPaper
			@see #getHtmlPaper
		*/
		getPaper: function() {
			return this.paper;
		},
		/*
			TODO get htmlpaper
			@return {object} HtmlPaper
		*/
		getHtmlPaper: function() {
			return this.paper;
		},
		/*
			TODO get raphael paper
			@return {object} Raphael
		*/
		getRaphaelPaper: function() {
			return this.raphaelPaper;
		},
		/*
			TODO clear all nodes
		*/
		clear: function() {
			this._$ctnNode.html("");
		},
		destroy: function() {
			// 销毁实例
			this.unbindEvt();
			this.clear();
		}
	});

	return BarChart;

}, {
	requires: [
		'gallery/template/1.0/index',
		'gallery/kcharts/1.2/basechart/index',
		'gallery/kcharts/1.2/raphael/index',
		'gallery/kcharts/1.2/tools/color/index',
		'gallery/kcharts/1.2/tools/htmlpaper/index',
		'gallery/kcharts/1.2/legend/index',
		'./theme',
		'gallery/kcharts/1.2/tools/touch/index',
		'gallery/kcharts/1.2/tip/index',
        'dom',
        'event'
	]
});