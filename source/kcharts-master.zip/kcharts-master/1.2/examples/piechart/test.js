data   ::= String || Object
object ::= {
  "success":Bool,
  "data":lists
}
lists  ::= [] || [{name:String(10)},...]

