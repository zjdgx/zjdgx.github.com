### ![Kcharts](http://img02.taobaocdn.com/tps/i2/T1TQygXEteXXXr6JI6-109-50.png)  ###
##基于KISSY的图表集合
* 包含业务常用图表类型
* 底层基于raphael图形库
* 采用html+css定制非矢量图形样式
* 包含全面文档和在线图表生成器


kcharts 主页: http://v.idcnc.com.cn
